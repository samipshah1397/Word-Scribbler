﻿CREATE TABLE [dbo].[bcdaa]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [word] NVARCHAR(50) NULL, 
    [meaning] NVARCHAR(50) NULL
)

﻿CREATE TABLE [dbo].[Table]
(
	[Word] NVARCHAR(50) NOT NULL, 
    [Meaning] NVARCHAR(50) NOT NULL, 
    CONSTRAINT [PK_Table] PRIMARY KEY ([Word]) 
)

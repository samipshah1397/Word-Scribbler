﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
      
        }



        private void button1_Click(object sender, EventArgs e)
        {
            
            int count = 0;
           
            SqlConnection cn = new SqlConnection(WindowsFormsApplication1.Properties.Settings.Default.Setting);
            
            cn.Open();
            string a = textBox1.Text;
            string search = "Select meaning from info where word=@word";
            
            
            SqlCommand cmd10 = new SqlCommand(search, cn);
            cmd10.Parameters.AddWithValue("@word", a);
            SqlDataReader sr = cmd10.ExecuteReader();


            if (sr.Read())
            {
                count++;
                richTextBox1.Text = Convert.ToString(sr["meaning"]);
            }
            else
            {
                MessageBox.Show("No such word in the List");
            }
          
            
            /*while (sr.Read())
            {
                count++;
                richTextBox1.Text = Convert.ToString(sr["meaning"]);
            }*/
          
            cn.Close();


        }

        private void button3_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(WindowsFormsApplication1.Properties.Settings.Default.Setting);

            cn.Open();

            // string insert = "INSERT INTO Table(word,meaning) VALUES('vemodalen','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('exulanasis','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('jouska','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('phosphenes','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('andune','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('acedia','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('frood','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('autophobe','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('grassed','abc')";
            // string insert = "INSERT INTO Table(word,meaning) VALUES('foma','abc')";
         
            
                       string a = "Authorized";
                      string b = "valid";
                       string query="insert into info values(@word,@meaning)";
                        SqlCommand cmd = new SqlCommand(query, cn);
                        cmd.Parameters.AddWithValue("@word", a);
                           cmd.Parameters.AddWithValue("@meaning", b);
          
            
            /*  SqlCommand cmd1 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('exulanasis','tendency to give up trying to talk about an experience because people are unable to relate to it')", cn);
              SqlCommand cmd2 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('jouska','hypothetical conversation that you compulsivly play in your mind')", cn);
              SqlCommand cmd3 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('phosphenes','the light and colours produced by rubbing your eyes')", cn);
              SqlCommand cmd4 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('andune','sunset')", cn);
              SqlCommand cmd5 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('acedia','laziness_indifference')", cn);
              SqlCommand cmd6 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('frood','a really amazingly together guy')", cn);
              SqlCommand cmd7 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('autophobe','a person with fear of being alone')", cn);
              SqlCommand cmd8 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('grassed','drunk')", cn);
              SqlCommand cmd9 = new SqlCommand("INSERT INTO Table(word,meaning) VALUES('foma','harmless untruths')", cn);
              */

          cmd.ExecuteNonQuery();
            /*cmd1.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            cmd3.ExecuteNonQuery();
            cmd4.ExecuteNonQuery();
            cmd5.ExecuteNonQuery();
            cmd6.ExecuteNonQuery();
            cmd7.ExecuteNonQuery();
            cmd8.ExecuteNonQuery();
            cmd9.ExecuteNonQuery();
           */
            cn.Close();
            MessageBox.Show("done");
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Selected)
                    textBox1.Text = listView1.Items[i].Text;
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void enter(object sender, KeyEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 fm = new Form3();
            fm.Show();
            this.Hide();
        }
    }
}

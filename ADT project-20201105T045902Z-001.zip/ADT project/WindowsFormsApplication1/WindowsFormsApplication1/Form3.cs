﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;

            SqlConnection cn = new SqlConnection(WindowsFormsApplication1.Properties.Settings.Default.Setting);

            cn.Open();
            string a = textBox1.Text;
            string search = "Select meaning from info ";


            SqlCommand cmd11 = new SqlCommand(search, cn);
           // cmd11.Parameters.AddWithValue("@meaning", a);
            SqlDataReader sr = cmd11.ExecuteReader();

            int i=0;
             string[] ab = new string[100];
            while (sr.Read())
            {
                count++;
               
                 ab[i] = Convert.ToString(sr["meaning"]);
                i++;
            }
                
            
            sr.Close();
            
            string search1 = "Select word from info where meaning=@meaning1";

                
                SqlCommand cmd111 = new SqlCommand(search1, cn);

            for(int k=0;k<i;k++)
            {   
                 cmd111.Parameters.AddWithValue("@meaning1", ab[k]);
                SqlDataReader sr1 = cmd111.ExecuteReader();

                while (sr1.Read())
                {

                    string ab1 = Convert.ToString(sr1["word"]);
                    listBox1.Items.Add(ab1);
                
                }
            
                sr1.Close();
            
            }


           
        
        
        
        
        
        
        }
    }
}

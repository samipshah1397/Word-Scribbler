﻿CREATE TABLE [dbo].[Table]
(
	[Word] NVARCHAR(50) NOT NULL, 
    [Meaning] NVARCHAR(50) NOT NULL 
)
